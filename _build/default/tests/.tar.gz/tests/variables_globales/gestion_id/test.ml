open Rat
open Compilateur
open Exceptions

exception ErreurNonDetectee

(****************************************)
(** Chemin d'accès aux fichiers de test *)
(****************************************)

let pathFichiersRat = "../../../../../tests/variables_globales/gestion_id/fichiersRat/"

(**********)
(*  TESTS *)
(**********)

let%test_unit "test1" =
let _ = compiler (pathFichiersRat ^ "test1.rat") in ()

let%test_unit "testVG2" =
let _ = compiler (pathFichiersRat ^ "test2.rat") in ()

let%test_unit "test3" =
let _ = compiler (pathFichiersRat ^ "test3.rat") in
()
let%test_unit "test4" =
try
let _ = compiler (pathFichiersRat ^ "test4.rat") in
raise ErreurNonDetectee
with IdentifiantNonDeclare "z" -> ()


(* Fichiers de tests de la génération de code -> doivent passer la TDS *)
open Unix
open Filename

let rec test d p_tam = 
  try 
    let file = readdir d in
    if (check_suffix file ".rat") 
    then
    (
     try
       let _ = compiler  (p_tam^file) in (); 
     with e -> print_string (p_tam^file); print_newline(); raise e;
    )
    else ();
    test d p_tam
  with End_of_file -> ()

let%test_unit "all_tam" =
  let p_tam = "../../../../../tests/tam/avec_fonction/fichiersRat/" in
  let d = opendir p_tam in
  test d p_tam